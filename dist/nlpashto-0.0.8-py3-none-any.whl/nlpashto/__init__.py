from nlpashto.functions import tokenizer, word_tokenizer, sentence_tokenizer, pos_tagger
