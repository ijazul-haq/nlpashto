def segment_words(text):
    return text