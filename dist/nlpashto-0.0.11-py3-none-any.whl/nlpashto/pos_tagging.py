def pos_tag(text):
    return text