from .spelling_correction import space_correct
from .word_segmentation import segment_words
from .pos_tagging import pos_tag
from .utils import *